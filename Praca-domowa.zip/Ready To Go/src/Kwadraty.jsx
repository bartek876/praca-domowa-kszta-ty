import "./scss/main.css";


function Kwadraty() {
    return <div className="tło">
        <div className='k1'></div>
        <div className="k2"></div>
        <div className="k3"></div>
        <div className="k4"></div>
        <div className="k5"></div>
        <div className="k6"></div>



    </div>;

}
export default Kwadraty;
