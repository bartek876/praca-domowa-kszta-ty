import React from 'react'
import ReactDOM from 'react-dom/client'
import './scss/main.css'
import Kwadraty from './Kwadraty'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Kwadraty />
  </React.StrictMode>
)
